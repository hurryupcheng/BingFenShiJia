//
//  BFFuctionButton.h
//  缤微纷购
//
//  Created by 程召华 on 16/3/5.
//  Copyright © 2016年 xinxincao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BFFuctionButton : UIButton

/**图片*/
@property (nonatomic, strong) UIImageView *functionImageView;
/**标题*/
@property (nonatomic, strong) UILabel *functionTitleLabel;

@end

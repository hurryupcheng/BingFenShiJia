//
//  BFBankButton.h
//  缤微纷购
//
//  Created by 程召华 on 16/3/9.
//  Copyright © 2016年 xinxincao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BFBankButton : UIButton
/**title*/
@property (nonatomic, strong) UILabel *buttonTitle;
@end

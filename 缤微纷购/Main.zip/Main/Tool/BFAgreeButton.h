//
//  BFAgreeButton.h
//  缤微纷购
//
//  Created by 程召华 on 16/3/9.
//  Copyright © 2016年 xinxincao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BFAgreeButton : UIButton
/**图片*/
@property (nonatomic, strong) UIImageView *agreeImageView;
/**标题*/
@property (nonatomic, strong) UILabel *agreeTitleLabel;
@end

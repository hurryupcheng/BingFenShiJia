//
//  BFGetYearAndMonth.h
//  缤微纷购
//
//  Created by 程召华 on 16/3/25.
//  Copyright © 2016年 xinxincao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BFGetYearAndMonth : NSObject
+ (NSArray *)getTenMonthBeforeTheCurrentTime;
@end

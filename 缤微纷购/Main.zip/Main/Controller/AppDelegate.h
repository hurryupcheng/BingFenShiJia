//
//  AppDelegate.h
//  缤微纷购
//
//  Created by 郑洋 on 16/1/4.
//  Copyright © 2016年 xinxincao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (nonatomic,assign)CGFloat proportionX;
@property (nonatomic,assign)CGFloat proportionY;

@property (nonatomic, strong) NSString *haha;
@end


//
//  STColor.m
//  STPhotoBrowser
//
//  Created by https://github.com/STShenZhaoliang/STPhotoBrowser.git on 16/1/15.
//  Copyright © 2016年 ST. All rights reserved.
//

#import "STColor.h"
#import "STConfig.h"
@implementation STColor

+ (UIColor *)colorIndicatorViewBackground {
    return RGBA(255, 255, 255, 0.7);
}

@end

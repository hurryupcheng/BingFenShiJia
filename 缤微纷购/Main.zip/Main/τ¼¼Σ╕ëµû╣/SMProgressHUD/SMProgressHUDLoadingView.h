//
//  SMProgressHUDLoadingView.h
//  SMProgressHUD
//
//  Created by OrangeLife on 15/10/10.
//  Copyright (c) 2015年 Shenme Studio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SMProgressHUDLoadingView : UIView
-(void)setTipText:(NSString *)tip;
@end
